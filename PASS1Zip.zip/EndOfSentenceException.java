import java.lang.Exception;

public class EndOfSentenceException extends Exception {
	private static final long serialVersionUID = 1L;

	public EndOfSentenceException() {
		super();
	}
}